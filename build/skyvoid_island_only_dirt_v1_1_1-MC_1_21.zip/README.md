## Dirt SkyBlock
### Starter Island
A classic skyblock island without a tree or chest (only dirt) is generated at the bottom of the world in a Snowy Taiga biome (at Y=-64). The world spawn point will be moved to the location of the middle grass block at Y=0, so mobs will be able to spawn on the island. The locator will fail if there isn't a snowy taiga within 2000 blocks, so some worlds will fail to generate the island. For more information, visit the [wiki](https://github.com/BPR02/SkyBlock_Collection/wiki).
