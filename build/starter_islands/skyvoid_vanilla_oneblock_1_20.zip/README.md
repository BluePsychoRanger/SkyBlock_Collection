## Vanilla One Block
### Starter Island
A single grass block will generate in a Snowy Taiga biome at Y=-61. The calculations are intensive, so to prevent the game from crashing, some worlds will fail to generate the island. For more information, visit the [wiki](https://github.com/BluePsychoRanger/SkyBlock_Collection/wiki).
