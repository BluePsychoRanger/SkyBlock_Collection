## No End Ship
The `skyvoid_no_end_ship` data pack disables the generation of the end ship blocks. For more information, visit the [wiki](https://github.com/BluePsychoRanger/SkyBlock_Collection/wiki).
