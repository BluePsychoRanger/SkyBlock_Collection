## Advancements Pack
The `skyvoid_advancements` data pack modifies the story and nether advancements to better guide the progression in a skyblock world. It rearranges vanilla advancements and adds extra advancements. For more information, visit the [wiki](https://github.com/BluePsychoRanger/SkyBlock_Collection/wiki).
