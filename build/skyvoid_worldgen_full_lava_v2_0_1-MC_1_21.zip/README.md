## Sky Void Worldgen (Full Lava)
The `skyvoid_worldgen_full_lava` data pack generates an infinite void world with properties akin to the original SkyBlock. Every end portal will have a 3x3 pit of lava beneath it. For more information, visit the [wiki](https://github.com/BPR02/SkyBlock_Collection/wiki).
