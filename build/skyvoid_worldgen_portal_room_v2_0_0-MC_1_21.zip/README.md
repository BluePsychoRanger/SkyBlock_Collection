## Sky Void Worldgen (Portal Room)
The `skyvoid_worldgen_portal_room` data pack generates an infinite void world with properties akin to the original SkyBlock. Strongholds will generate with the full portal room. For more information, visit the [wiki](https://github.com/BluePsychoRanger/SkyBlock_Collection/wiki).
