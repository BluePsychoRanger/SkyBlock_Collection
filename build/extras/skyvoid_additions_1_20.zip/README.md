## Sky Void Additions
The `skyvoid_additions` data pack adds new mechanics to the game, allowing for all items, mobs, and advancements to be obtainable in skyblock. For more information, visit the [wiki](https://github.com/BluePsychoRanger/SkyBlock_Collection/wiki).
