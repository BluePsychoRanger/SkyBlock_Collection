## Sky Void Worldgen (Pinu Custom)
The `skyvoid_worldgen_pinu` data pack generates an infinite void world with properties akin to the original SkyBlock, except with a normal end dimension. Only the portal room will generate in strongholds. For more information, visit the [wiki](https://github.com/BPR02/SkyBlock_Collection/wiki).
